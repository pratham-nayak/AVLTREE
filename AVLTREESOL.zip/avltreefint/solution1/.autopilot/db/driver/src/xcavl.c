// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcavl.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCavl_CfgInitialize(XCavl *InstancePtr, XCavl_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Slaveport_BaseAddress = ConfigPtr->Slaveport_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCavl_Start(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL) & 0x80;
    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCavl_IsDone(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCavl_IsIdle(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCavl_IsReady(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCavl_EnableAutoRestart(XCavl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL, 0x80);
}

void XCavl_DisableAutoRestart(XCavl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_CTRL, 0);
}

u32 XCavl_Get_return(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_AP_RETURN);
    return Data;
}
void XCavl_Set_SlaveAXI(XCavl *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_SLAVEAXI_DATA, Data);
}

u32 XCavl_Get_SlaveAXI(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_SLAVEAXI_DATA);
    return Data;
}

void XCavl_Set_input_r(XCavl *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_INPUT_R_DATA, Data);
}

u32 XCavl_Get_input_r(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_INPUT_R_DATA);
    return Data;
}

void XCavl_Set_SelectTestCase(XCavl *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_SELECTTESTCASE_DATA, Data);
}

u32 XCavl_Get_SelectTestCase(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_SELECTTESTCASE_DATA);
    return Data;
}

void XCavl_Set_root_in(XCavl *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_ROOT_IN_DATA, Data);
}

u32 XCavl_Get_root_in(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_ROOT_IN_DATA);
    return Data;
}

void XCavl_Set_key_in(XCavl *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_KEY_IN_DATA, Data);
}

u32 XCavl_Get_key_in(XCavl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_KEY_IN_DATA);
    return Data;
}

void XCavl_InterruptGlobalEnable(XCavl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_GIE, 1);
}

void XCavl_InterruptGlobalDisable(XCavl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_GIE, 0);
}

void XCavl_InterruptEnable(XCavl *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_IER);
    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_IER, Register | Mask);
}

void XCavl_InterruptDisable(XCavl *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_IER);
    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_IER, Register & (~Mask));
}

void XCavl_InterruptClear(XCavl *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCavl_WriteReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_ISR, Mask);
}

u32 XCavl_InterruptGetEnabled(XCavl *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_IER);
}

u32 XCavl_InterruptGetStatus(XCavl *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCavl_ReadReg(InstancePtr->Slaveport_BaseAddress, XCAVL_SLAVEPORT_ADDR_ISR);
}

