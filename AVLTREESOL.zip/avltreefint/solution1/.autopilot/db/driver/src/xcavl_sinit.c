// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xcavl.h"

extern XCavl_Config XCavl_ConfigTable[];

XCavl_Config *XCavl_LookupConfig(u16 DeviceId) {
	XCavl_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCAVL_NUM_INSTANCES; Index++) {
		if (XCavl_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCavl_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCavl_Initialize(XCavl *InstancePtr, u16 DeviceId) {
	XCavl_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCavl_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCavl_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

